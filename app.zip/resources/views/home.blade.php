@extends('layouts.app')
@section('title','MyStore — Curated goods for modern living')
@section('content')
<section class="hero" data-slider>
 @foreach([
 ['img'=>'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=2200&q=85','eyebrow'=>'The new season','title'=>'Objects with','span'=>'presence.','desc'=>'A refined collection of everyday pieces designed to make modern living feel considered.'],
 ['img'=>'https://images.unsplash.com/photo-1494438639946-1ebd1d20bf85?auto=format&fit=crop&w=2200&q=85','eyebrow'=>'Quiet luxury','title'=>'Designed for','span'=>'every day.','desc'=>'Premium materials, thoughtful details and timeless forms — selected with intention.'],
 ['img'=>'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?auto=format&fit=crop&w=2200&q=85','eyebrow'=>'Curated commerce','title'=>'Less noise.','span'=>'Better choices.','desc'=>'Discover pieces that earn their place in your home, wardrobe and daily rituals.']
 ] as $i=>$slide)
 <div class="hero-slide {{ $i===0?'active':'' }}"><img src="{{ $slide['img'] }}" alt=""><div class="hero-content"><div class="container"><div class="hero-copy"><div class="eyebrow">{{ $slide['eyebrow'] }}</div><h1>{{ $slide['title'] }} <span>{{ $slide['span'] }}</span></h1><p>{{ $slide['desc'] }}</p><div class="actions"><a class="btn btn-primary" href="{{ route('products.index') }}">Explore collection ↗</a><a class="btn btn-ghost" href="{{ route('collections') }}">View collections</a></div></div></div></div></div>
 @endforeach
 <div class="container hero-controls"><div class="slider-dots">@for($i=0;$i<3;$i++)<button class="slider-dot {{ $i===0?'active':'' }}" aria-label="Slide {{ $i+1 }}"></button>@endfor</div><div class="slider-arrows"><button data-prev>←</button><button data-next>→</button></div></div>
</section>

<section class="trust"><div class="container trust-grid">
 @foreach([['✦','Curated quality','Every piece is selected with intent'],['↗','Fast dispatch','Carefully packed and shipped'],['◇','Secure checkout','Protected payments end to end'],['↩','Easy returns','A simple, considered process']] as $t)<div class="trust-item"><div class="trust-icon">{{ $t[0] }}</div><div><strong>{{ $t[1] }}</strong><div style="font-size:10px;color:var(--muted)">{{ $t[2] }}</div></div></div>@endforeach
</div></section>

<section class="section"><div class="container"><div class="section-head"><div><div class="eyebrow">Explore the edit</div><h2>Shop by collection.</h2><p class="section-copy">Move through our curated categories and find the pieces that fit your world.</p></div><a class="link" href="{{ route('products.index') }}">Shop all ↗</a></div>
<div class="category-slider" id="category-slider">
 @forelse($categories as $i=>$category)
 <a class="category-card" href="{{ route('products.category',$category->slug) }}"><img src="{{ $category->image ?: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=900&q=80' }}" alt="{{ $category->name }}"><div class="category-info"><small>{{ str_pad($i+1,2,'0',STR_PAD_LEFT) }} · Collection</small><h3>{{ $category->name }}</h3></div></a>
 @empty
 <div class="page-card">Create active categories in the admin panel to populate this slider.</div>
 @endforelse
</div></div></section>

<section class="section alt"><div class="container"><div class="section-head"><div><div class="eyebrow">Selected now</div><h2>Featured pieces.</h2><p class="section-copy">A rotating edit of products marked featured by the MyStore team.</p></div><a class="link" href="{{ route('products.index') }}">View all products ↗</a></div>
<div class="product-slider" id="product-slider">
 @forelse($featured as $product)
 <article class="product-card"><div class="product-media"><img src="{{ $product->image ?: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=80' }}" alt="{{ $product->name }}" loading="lazy"><button class="like-btn" data-like="{{ $product->id }}">♡</button></div><div class="product-info"><div class="product-category">{{ $product->category?->name ?? 'Featured' }}</div><h3>{{ $product->name }}</h3><div class="price-row"><span class="price">${{ number_format($product->sale_price ?: $product->price,2) }}</span>@if($product->sale_price)<span class="old-price">${{ number_format($product->price,2) }}</span>@endif</div><div class="product-actions"><a class="btn" href="{{ route('products.show',$product->slug) }}">View</a>@auth<form action="{{ route('cart.add',$product) }}" method="POST" style="flex:1">@csrf<button class="btn btn-primary" style="width:100%">Add to bag</button></form>@else<a class="btn btn-primary" href="{{ route('login') }}">Add to bag</a>@endauth</div></div></article>
 @empty <div class="page-card">No featured products yet. Add featured products from Admin → Products.</div>@endforelse
</div></div></section>

<section class="section"><div class="container split"><div class="story-card"><img src="https://images.unsplash.com/photo-1494438639946-1ebd1d20bf85?auto=format&fit=crop&w=1400&q=85" alt=""><div class="story-content"><div class="eyebrow" style="color:#b8d0ff">The MyStore philosophy</div><h2>Good design should disappear into your life.</h2><p style="color:rgba(255,255,255,.7)">We look for balance: useful objects, honest materials, considered silhouettes and details that reward a second look.</p><a class="btn btn-ghost" href="{{ route('about') }}">Our story ↗</a></div></div><div class="page-card" style="display:flex;flex-direction:column;justify-content:center;padding:48px"><div class="eyebrow">Why MyStore</div><h2>Premium without the noise.</h2><p class="section-copy">We keep the catalogue intentional, the experience calm and the quality uncompromising.</p><div style="display:grid;gap:13px;margin-top:25px">@foreach(['Thoughtful selection','Transparent pricing','Secure checkout','Responsive support'] as $x)<div style="display:flex;gap:10px;align-items:center;font-weight:700"><span style="color:var(--primary)">✦</span>{{ $x }}</div>@endforeach</div></div></div></section>

<section class="section alt"><div class="container"><div class="section-head"><div><div class="eyebrow">The standard</div><h2>Built around better basics.</h2></div></div><div class="benefit-grid">@foreach([['01','Quality first','Materials and details chosen for everyday longevity.'],['02','Intentional edit','Less clutter. More products worth considering.'],['03','Seamless service','From discovery to delivery, every step feels considered.'],['04','Human support','Questions are welcome. We are here when you need us.']] as $b)<div class="benefit"><div class="benefit-icon">{{ $b[0] }}</div><h3>{{ $b[1] }}</h3><p>{{ $b[2] }}</p></div>@endforeach</div></div></section>

<section class="section"><div class="container"><div class="section-head"><div><div class="eyebrow">Customer notes</div><h2>Loved in real life.</h2><p class="section-copy">A few words from the people who keep coming back.</p></div></div><div class="testimonial-grid">@foreach([['Ava Morgan','The whole experience feels exceptionally polished — from the product pages to the packaging.'],['Daniel Lee','The quality is exactly what the photos promise. My second order is already on the way.'],['Mia Carter','Simple, beautiful and fast. It is rare for an online store to feel this calm.']] as $r)<article class="testimonial"><div class="stars">★★★★★</div><p>“{{ $r[1] }}”</p><div class="person"><div class="person-avatar">{{ $r[0][0] }}</div><div><strong>{{ $r[0] }}</strong><div style="font-size:10px;color:var(--muted)">Verified customer</div></div></div></article>@endforeach</div></div></section>

<section class="section alt"><div class="container"><div class="newsletter"><div class="eyebrow" style="color:#bcd0ff">The journal</div><h2>Ideas, edits and new arrivals.</h2><p class="section-copy">Explore the latest stories, buying guides and product notes from MyStore.</p><a class="btn btn-primary" href="{{ route('blog') }}">Read the journal ↗</a></div></div></section>
@endsection