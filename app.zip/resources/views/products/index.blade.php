@extends('layouts.app')
@section('title','Shop · MyStore')
@section('content')
<section class="page-hero"><div class="container"><div class="breadcrumbs">MyStore / Shop</div><h1>Shop the edit.</h1><p>Explore the full catalogue of considered products. Save what you love and add favourites to your bag.</p></div></section>
<section class="section"><div class="container">
<div class="section-head"><div><div class="eyebrow">All products</div><h2>{{ $products->total() }} pieces.</h2></div></div>
<div class="grid-products">
@foreach($products as $product)
<article class="product-card"><div class="product-media"><img src="{{ $product->image ?: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=80' }}" alt="{{ $product->name }}" loading="lazy"><button class="like-btn" data-like="{{ $product->id }}">♡</button></div><div class="product-info"><div class="product-category">{{ $product->category?->name ?? 'Collection' }}</div><h3>{{ $product->name }}</h3><div class="price-row"><span class="price">${{ number_format($product->sale_price ?: $product->price,2) }}</span>@if($product->sale_price)<span class="old-price">${{ number_format($product->price,2) }}</span>@endif</div><div class="product-actions"><a class="btn" href="{{ route('products.show',$product->slug) }}">Details</a>@auth<form action="{{ route('cart.add',$product) }}" method="POST" style="flex:1">@csrf<button class="btn btn-primary" style="width:100%">Add to bag</button></form>@else<a class="btn btn-primary" href="{{ route('login') }}">Add to bag</a>@endauth</div></div></article>
@endforeach
</div><div class="pagination">{{ $products->links() }}</div>
</div></section>
@endsection