@extends('layouts.app')
@section('title',$title.' · MyStore')
@section('content')
<section class="page-hero"><div class="container"><div class="breadcrumbs">MyStore / {{ ucfirst($page) }}</div><div class="eyebrow">{{ $eyebrow }}</div><h1>{{ $title }}</h1><p>{{ $intro }}</p></div></section>
<section class="section"><div class="container">
@if($page==='contact')
<div class="split"><div class="page-card"><div class="eyebrow">Contact</div><h2>Tell us what you need.</h2><form class="auth-form"><div class="field"><label>Name</label><input placeholder="Your name"></div><div class="field"><label>Email</label><input type="email" placeholder="you@example.com"></div><div class="field"><label>Message</label><textarea placeholder="How can we help?"></textarea></div><button type="button" class="btn btn-primary">Send message</button></form></div><div class="page-card"><div class="eyebrow">Support</div><h2>We typically reply within one business day.</h2><p class="section-copy">For order questions, include your order number so we can help faster.</p></div></div>
@elseif($page==='faq')
<div style="display:grid;gap:12px">@foreach(['How long does shipping take?'=>'Most orders are dispatched promptly; delivery timing depends on destination and carrier.','Can I return an item?'=>'Yes. Contact support with your order details and we will guide you through the process.','Are payments secure?'=>'Yes. Checkout uses your existing secure payment flow.','Can I update my profile?'=>'Yes. Visit your account profile page to update your information.'] as $q=>$a)<details class="page-card"><summary style="font-weight:800;cursor:pointer">{{ $q }}</summary><p class="section-copy">{{ $a }}</p></details>@endforeach</div>
@elseif(in_array($page,['gallery','portfolio']))
<div class="category-slider">@foreach(['https://images.unsplash.com/photo-1494438639946-1ebd1d20bf85','https://images.unsplash.com/photo-1441986300917-64674bd600d8','https://images.unsplash.com/photo-1556742049-0cfed4f6a45d','https://images.unsplash.com/photo-1523275335684-37898b6baf30'] as $img)<div class="category-card"><img src="{{ $img }}?auto=format&fit=crop&w=900&q=85" alt=""><div class="category-info"><small>MyStore / Edit</small><h3>Considered details.</h3></div></div>@endforeach</div>
@else
<div class="split"><div class="page-card"><div class="eyebrow">Our approach</div><h2>Clarity over clutter.</h2><p class="section-copy">Every touchpoint is designed around a simple idea: make it easy to discover, understand and choose something you will genuinely use.</p></div><div class="page-card"><div class="eyebrow">The promise</div><h2>Premium, useful, human.</h2><p class="section-copy">We care about the details — product presentation, clear information, reliable service and a visual system that stays out of the way.</p></div></div>
@endif
</div></section>
@endsection