<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>@yield('title','MyStore')</title>
<link rel="stylesheet" href="{{ asset('premium.css') }}">
<script>document.documentElement.dataset.theme=localStorage.getItem('mystore-theme')||'blue';</script>
</head>
<body>
<div class="topbar">Complimentary shipping on orders over $100 · Curated for modern living</div>
<header class="site-header">
 <div class="container nav">
  <a class="brand" href="{{ route('home') }}"><span class="brand-mark">M</span><span><span class="brand-name">MYSTORE</span><span class="brand-sub">CURATED GOODS</span></span></a>
  <nav class="nav-links">
   <a href="{{ route('home') }}" class="{{ request()->routeIs('home')?'active':'' }}">Home</a>
   <a href="{{ route('products.index') }}" class="{{ request()->routeIs('products.*')?'active':'' }}">Shop</a>
   <a href="{{ route('about') }}">About</a><a href="{{ route('collections') }}">Collections</a><a href="{{ route('contact') }}">Contact</a>
  </nav>
  <div class="nav-actions">
   <a class="icon-btn" href="{{ route('products.index') }}" aria-label="Search">⌕</a>
   @auth
    <a class="icon-btn" style="position:relative" href="{{ route('cart.index') }}" aria-label="Cart">Bag<span class="cart-badge">{{ \App\Models\CartItem::where('user_id',auth()->id())->sum('quantity') }}</span></a>
    <a class="user-chip" href="{{ route('dashboard') }}"><span class="avatar">{{ strtoupper(substr(auth()->user()->name,0,1)) }}</span><span>{{ auth()->user()->name }}</span></a>
    @if(auth()->user()->role === 'admin')<a class="icon-btn" href="{{ url('/admin') }}" title="Admin">⚙</a>@endif
   @else
    <a class="btn btn-primary" href="{{ route('login') }}">Sign in</a>
   @endauth
  </div>
 </div>
</header>
<main class="page-main">@if(session('success'))<div class="container" style="padding-top:16px"><div class="alert success">{{ session('success') }}</div></div>@endif @if(session('error'))<div class="container" style="padding-top:16px"><div class="alert error">{{ session('error') }}</div></div>@endif @yield('content')</main>
<footer class="footer">
 <div class="container footer-grid">
  <div><a class="brand" href="{{ route('home') }}"><span class="brand-mark">M</span><span class="brand-name" style="color:#fff">MYSTORE</span></a><p style="color:rgba(255,255,255,.55);max-width:280px;font-size:12px;margin-top:18px">A premium digital storefront for beautifully considered everyday essentials.</p></div>
  <div><div class="footer-title">Shop</div><a href="{{ route('products.index') }}">All Products</a><a href="{{ route('collections') }}">Collections</a><a href="{{ route('about') }}">Our Story</a></div>
  <div><div class="footer-title">Support</div><a href="{{ route('contact') }}">Contact</a><a href="{{ route('faq') }}">FAQ</a><a href="{{ route('shipping') }}">Shipping</a><a href="{{ route('returns') }}">Returns</a></div>
  <div><div class="footer-title">Company</div><a href="{{ route('careers') }}">Careers</a><a href="{{ route('blog') }}">Journal</a><a href="{{ route('privacy') }}">Privacy</a><a href="{{ route('terms') }}">Terms</a></div>
  <div><div class="footer-title">Account</div>@auth<a href="{{ route('dashboard') }}">Dashboard</a><a href="{{ route('orders.index') }}">Orders</a><a href="{{ route('profile.edit') }}">Profile</a>@else<a href="{{ route('login') }}">Sign in</a><a href="{{ route('register') }}">Create account</a>@endauth</div>
 </div>
 <div class="container footer-bottom"><span>© {{ date('Y') }} MyStore. All rights reserved.</span><span>Designed with precision · Built for modern commerce</span></div>
</footer>
<div class="theme-fab" aria-label="Theme switch"><button data-theme-btn="blue" onclick="setStoreTheme('blue')" title="Navy / White">◐</button><button data-theme-btn="luxury" onclick="setStoreTheme('luxury')" title="Black / Gold / White">◆</button></div>
<script src="{{ asset('premium.js') }}"></script>
</body></html>