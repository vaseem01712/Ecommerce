<x-filament-panels::page>

    <div class="premium-dashboard">

        {{-- HEADER --}}
        <div class="dashboard-header">

            <div>
                <div class="dashboard-eyebrow">
                    MY STORE / ADMIN
                </div>

                <h1>
                    Dashboard
                </h1>

                <p>
                    Here's what's happening across your store.
                </p>
            </div>

            <div class="dashboard-actions">

                <a href="{{ url('/admin/products/create') }}"
                   class="primary-action">
                    + Add Product
                </a>

                <a href="{{ url('/admin/categories/create') }}"
                   class="secondary-action">
                    + Category
                </a>

            </div>

        </div>


        {{-- STAT CARDS --}}
        <div class="stats-grid">

            {{-- REVENUE --}}
            <div class="stat-card">

                <div class="stat-top">
                    <span>Revenue</span>

                    <div class="stat-icon revenue-icon">
                        $
                    </div>
                </div>

                <div class="stat-value">
                    ${{ number_format($revenue, 2) }}
                </div>

                <div class="stat-description">
                    Active + completed orders
                </div>

            </div>


            {{-- ORDERS --}}
            <div class="stat-card">

                <div class="stat-top">
                    <span>Orders</span>

                    <div class="stat-icon order-icon">
                        #
                    </div>
                </div>

                <div class="stat-value">
                    {{ number_format($ordersCount) }}
                </div>

                <div class="stat-description blue">
                    All customer orders
                </div>

            </div>


            {{-- PRODUCTS --}}
            <div class="stat-card">

                <div class="stat-top">
                    <span>Products</span>

                    <div class="stat-icon product-icon">
                        ◈
                    </div>
                </div>

                <div class="stat-value">
                    {{ number_format($productsCount) }}
                </div>

                <div class="stat-description green">
                    {{ $outOfStock }} out of stock
                </div>

            </div>


            {{-- CUSTOMERS --}}
            <div class="stat-card">

                <div class="stat-top">
                    <span>Customers</span>

                    <div class="stat-icon customer-icon">
                        ◎
                    </div>
                </div>

                <div class="stat-value">
                    {{ number_format($customersCount) }}
                </div>

                <div class="stat-description purple">
                    Registered shoppers
                </div>

            </div>

        </div>


        {{-- MAIN GRID --}}
        <div class="dashboard-main-grid">


            {{-- RECENT ORDERS --}}
            <section class="dashboard-card orders-card">

                <div class="card-header">

                    <div>
                        <h2>Recent Orders</h2>

                        <p>
                            Latest customer activity across the store.
                        </p>
                    </div>

                    <a href="{{ url('/admin/orders') }}"
                       class="view-all">
                        View all →
                    </a>

                </div>


                <div class="orders-table-wrapper">

                    <table class="orders-table">

                        <thead>
                            <tr>
                                <th>ORDER</th>
                                <th>CUSTOMER</th>
                                <th>TOTAL</th>
                                <th>STATUS</th>
                                <th>DATE</th>
                            </tr>
                        </thead>

                        <tbody>

                            @forelse($orders as $order)

                                <tr>

                                    <td>
                                        <span class="order-number">
                                            #{{ $order->id }}
                                        </span>
                                    </td>


                                    <td>

                                        <div class="customer-cell">

                                            <div class="customer-avatar">
                                                {{ strtoupper(substr($order->user->name ?? 'G', 0, 1)) }}
                                            </div>

                                            <div>
                                                <strong>
                                                    {{ $order->user->name ?? 'Guest Customer' }}
                                                </strong>

                                                <small>
                                                    {{ $order->user->email ?? '—' }}
                                                </small>
                                            </div>

                                        </div>

                                    </td>


                                    <td>
                                        <strong class="order-total">
                                            ${{ number_format($order->total ?? 0, 2) }}
                                        </strong>
                                    </td>


                                    <td>

                                        @php
                                            $status = strtolower($order->status ?? 'pending');
                                        @endphp

                                        <span class="status-badge status-{{ $status }}">
                                            <span class="status-dot"></span>
                                            {{ ucfirst($status) }}
                                        </span>

                                    </td>


                                    <td>
                                        <span class="order-date">
                                            {{ $order->created_at?->format('M d, Y') }}
                                        </span>
                                    </td>

                                </tr>

                            @empty

                                <tr>
                                    <td colspan="5">

                                        <div class="empty-orders">

                                            <div class="empty-icon">
                                                ◎
                                            </div>

                                            <h3>No orders yet</h3>

                                            <p>
                                                Customer orders will appear here.
                                            </p>

                                        </div>

                                    </td>
                                </tr>

                            @endforelse

                        </tbody>

                    </table>

                </div>

            </section>


            {{-- INVENTORY --}}
            <section class="dashboard-card inventory-card">

                <div class="card-header">

                    <div>
                        <h2>Inventory</h2>

                        <p>
                            Current stock health.
                        </p>
                    </div>

                    <a href="{{ url('/admin/products') }}"
                       class="view-all">
                        Manage →
                    </a>

                </div>


                <div class="inventory-content">


                    {{-- HEALTHY --}}
                    <div class="inventory-item">

                        <div class="inventory-left">

                            <div class="inventory-icon healthy">
                                ✓
                            </div>

                            <div>
                                <strong>Healthy stock</strong>

                                <span>
                                    Products with sufficient inventory
                                </span>
                            </div>

                        </div>

                        <strong class="inventory-number">
                            {{ $healthyStock }}
                        </strong>

                    </div>


                    {{-- LOW STOCK --}}
                    <div class="inventory-item">

                        <div class="inventory-left">

                            <div class="inventory-icon warning">
                                !
                            </div>

                            <div>
                                <strong>Low stock</strong>

                                <span>
                                    Products needing restock
                                </span>
                            </div>

                        </div>

                        <strong class="inventory-number">
                            {{ $lowStock }}
                        </strong>

                    </div>


                    {{-- OUT OF STOCK --}}
                    <div class="inventory-item">

                        <div class="inventory-left">

                            <div class="inventory-icon danger">
                                ×
                            </div>

                            <div>
                                <strong>Out of stock</strong>

                                <span>
                                    Products unavailable
                                </span>
                            </div>

                        </div>

                        <strong class="inventory-number">
                            {{ $outOfStock }}
                        </strong>

                    </div>


                </div>


                <a href="{{ url('/admin/products') }}"
                   class="inventory-button">

                    Open Inventory

                    <span>→</span>

                </a>

            </section>

        </div>


        {{-- QUICK ACTIONS --}}
        <section class="quick-actions">

            <div class="quick-heading">

                <div>
                    <h2>Quick actions</h2>

                    <p>
                        Manage your store faster.
                    </p>
                </div>

            </div>


            <div class="quick-grid">

                <a href="{{ url('/admin/products/create') }}"
                   class="quick-card">

                    <div class="quick-icon">
                        +
                    </div>

                    <div>
                        <strong>Add product</strong>

                        <span>
                            Create a new product
                        </span>
                    </div>

                    <b>→</b>

                </a>


                <a href="{{ url('/admin/categories/create') }}"
                   class="quick-card">

                    <div class="quick-icon">
                        ◈
                    </div>

                    <div>
                        <strong>Add category</strong>

                        <span>
                            Organise your catalogue
                        </span>
                    </div>

                    <b>→</b>

                </a>


                <a href="{{ url('/admin/orders') }}"
                   class="quick-card">

                    <div class="quick-icon">
                        #
                    </div>

                    <div>
                        <strong>Manage orders</strong>

                        <span>
                            Review customer orders
                        </span>
                    </div>

                    <b>→</b>

                </a>


                <a href="{{ url('/admin/customers') }}"
                   class="quick-card">

                    <div class="quick-icon">
                        ◎
                    </div>

                    <div>
                        <strong>Customers</strong>

                        <span>
                            View your shoppers
                        </span>
                    </div>

                    <b>→</b>

                </a>

            </div>

        </section>

    </div>


    <style>

        .premium-dashboard {
            width: 100%;
            max-width: 1500px;
            margin: 0 auto;
            padding: 10px 0 50px;
        }


        /* HEADER */

        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            gap: 30px;
            margin-bottom: 30px;
        }

        .dashboard-eyebrow {
            font-size: 11px;
            font-weight: 700;
            letter-spacing: .14em;
            color: #64748b;
            margin-bottom: 8px;
        }

        .dashboard-header h1 {
            margin: 0;
            font-size: 38px;
            line-height: 1;
            font-weight: 800;
            letter-spacing: -.04em;
            color: #0f172a;
        }

        .dashboard-header p {
            margin: 12px 0 0;
            color: #64748b;
            font-size: 14px;
        }


        .dashboard-actions {
            display: flex;
            gap: 10px;
        }

        .primary-action,
        .secondary-action {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 44px;
            padding: 0 18px;
            border-radius: 12px;
            text-decoration: none;
            font-size: 13px;
            font-weight: 700;
            transition: .2s ease;
        }

        .primary-action {
            color: white;
            background: #0f172a;
        }

        .primary-action:hover {
            transform: translateY(-2px);
            background: #1e293b;
        }

        .secondary-action {
            color: #0f172a;
            background: white;
            border: 1px solid #e2e8f0;
        }

        .secondary-action:hover {
            background: #f8fafc;
        }


        /* STATS */

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 16px;
            margin-bottom: 18px;
        }

        .stat-card {
            position: relative;
            overflow: hidden;
            padding: 22px;
            min-height: 155px;
            border-radius: 18px;
            background: rgba(255,255,255,.95);
            border: 1px solid #e5e7eb;
            box-shadow:
                0 10px 35px rgba(15,23,42,.05);
            transition: .25s ease;
        }

        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow:
                0 18px 45px rgba(15,23,42,.09);
        }

        .stat-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: #64748b;
            font-size: 12px;
            font-weight: 600;
        }

        .stat-icon {
            width: 38px;
            height: 38px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 11px;
            font-weight: 800;
            font-size: 16px;
        }

        .revenue-icon {
            color: #059669;
            background: #ecfdf5;
        }

        .order-icon {
            color: #2563eb;
            background: #eff6ff;
        }

        .product-icon {
            color: #7c3aed;
            background: #f5f3ff;
        }

        .customer-icon {
            color: #db2777;
            background: #fdf2f8;
        }

        .stat-value {
            margin-top: 15px;
            font-size: 30px;
            font-weight: 800;
            letter-spacing: -.04em;
            color: #0f172a;
        }

        .stat-description {
            margin-top: 6px;
            font-size: 12px;
            color: #059669;
            font-weight: 600;
        }

        .stat-description.blue {
            color: #2563eb;
        }

        .stat-description.green {
            color: #059669;
        }

        .stat-description.purple {
            color: #7c3aed;
        }


        /* MAIN */

        .dashboard-main-grid {
            display: grid;
            grid-template-columns: minmax(0, 1.55fr) minmax(360px, .85fr);
            gap: 18px;
        }

        .dashboard-card {
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 18px;
            box-shadow: 0 10px 35px rgba(15,23,42,.045);
            overflow: hidden;
        }


        .card-header {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 20px;
            padding: 22px 24px;
            border-bottom: 1px solid #eef2f7;
        }

        .card-header h2 {
            margin: 0;
            color: #0f172a;
            font-size: 17px;
            font-weight: 750;
            letter-spacing: -.02em;
        }

        .card-header p {
            margin: 5px 0 0;
            color: #94a3b8;
            font-size: 12px;
        }

        .view-all {
            white-space: nowrap;
            color: #2563eb;
            text-decoration: none;
            font-size: 12px;
            font-weight: 700;
        }

        .view-all:hover {
            color: #1d4ed8;
        }


        /* ORDERS */

        .orders-table-wrapper {
            overflow-x: auto;
        }

        .orders-table {
            width: 100%;
            border-collapse: collapse;
        }

        .orders-table th {
            padding: 14px 20px;
            text-align: left;
            color: #94a3b8;
            font-size: 10px;
            font-weight: 800;
            letter-spacing: .09em;
            background: #fafbfc;
            border-bottom: 1px solid #eef2f7;
        }

        .orders-table td {
            padding: 15px 20px;
            border-bottom: 1px solid #f1f5f9;
            white-space: nowrap;
            vertical-align: middle;
        }

        .orders-table tbody tr {
            transition: .18s ease;
        }

        .orders-table tbody tr:hover {
            background: #f8fafc;
        }

        .orders-table tbody tr:last-child td {
            border-bottom: 0;
        }

        .order-number {
            color: #0f172a;
            font-size: 13px;
            font-weight: 750;
        }

        .customer-cell {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .customer-avatar {
            width: 32px;
            height: 32px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #eff6ff;
            color: #2563eb;
            font-size: 11px;
            font-weight: 800;
        }

        .customer-cell strong {
            display: block;
            color: #1e293b;
            font-size: 12px;
        }

        .customer-cell small {
            display: block;
            margin-top: 2px;
            color: #94a3b8;
            font-size: 10px;
        }

        .order-total {
            color: #0f172a;
            font-size: 12px;
        }

        .order-date {
            color: #64748b;
            font-size: 11px;
        }


        /* STATUS */

        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 9px;
            border-radius: 999px;
            font-size: 10px;
            font-weight: 750;
        }

        .status-dot {
            width: 5px;
            height: 5px;
            border-radius: 50%;
            background: currentColor;
        }

        .status-pending {
            color: #b45309;
            background: #fffbeb;
        }

        .status-paid {
            color: #047857;
            background: #ecfdf5;
        }

        .status-processing {
            color: #2563eb;
            background: #eff6ff;
        }

        .status-completed,
        .status-delivered {
            color: #047857;
            background: #ecfdf5;
        }

        .status-cancelled,
        .status-canceled {
            color: #dc2626;
            background: #fef2f2;
        }

        .status-shipped {
            color: #7c3aed;
            background: #f5f3ff;
        }


        /* INVENTORY */

        .inventory-content {
            padding: 8px 24px 15px;
        }

        .inventory-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 0;
            border-bottom: 1px solid #f1f5f9;
        }

        .inventory-item:last-child {
            border-bottom: 0;
        }

        .inventory-left {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .inventory-icon {
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 900;
        }

        .inventory-icon.healthy {
            color: #059669;
            background: #ecfdf5;
        }

        .inventory-icon.warning {
            color: #d97706;
            background: #fffbeb;
        }

        .inventory-icon.danger {
            color: #dc2626;
            background: #fef2f2;
        }

        .inventory-left strong {
            display: block;
            color: #1e293b;
            font-size: 12px;
        }

        .inventory-left span {
            display: block;
            margin-top: 3px;
            color: #94a3b8;
            font-size: 10px;
        }

        .inventory-number {
            color: #0f172a;
            font-size: 17px;
        }

        .inventory-button {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin: 0 24px 22px;
            padding: 12px 14px;
            border-radius: 11px;
            color: #0f172a;
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            text-decoration: none;
            font-size: 12px;
            font-weight: 750;
            transition: .2s ease;
        }

        .inventory-button:hover {
            background: #f1f5f9;
        }


        /* QUICK ACTIONS */

        .quick-actions {
            margin-top: 18px;
        }

        .quick-heading {
            margin-bottom: 12px;
        }

        .quick-heading h2 {
            margin: 0;
            color: #0f172a;
            font-size: 17px;
            font-weight: 750;
        }

        .quick-heading p {
            margin: 4px 0 0;
            color: #94a3b8;
            font-size: 12px;
        }

        .quick-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
        }

        .quick-card {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 16px;
            border-radius: 15px;
            background: white;
            border: 1px solid #e5e7eb;
            text-decoration: none;
            box-shadow: 0 8px 25px rgba(15,23,42,.035);
            transition: .2s ease;
        }

        .quick-card:hover {
            transform: translateY(-2px);
            border-color: #cbd5e1;
            box-shadow: 0 14px 35px rgba(15,23,42,.08);
        }

        .quick-icon {
            width: 38px;
            height: 38px;
            flex: 0 0 38px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 11px;
            color: #2563eb;
            background: #eff6ff;
            font-size: 18px;
            font-weight: 800;
        }

        .quick-card strong {
            display: block;
            color: #0f172a;
            font-size: 12px;
        }

        .quick-card span {
            display: block;
            margin-top: 3px;
            color: #94a3b8;
            font-size: 10px;
        }

        .quick-card b {
            margin-left: auto;
            color: #94a3b8;
            font-size: 14px;
        }


        /* EMPTY */

        .empty-orders {
            padding: 45px 20px;
            text-align: center;
        }

        .empty-icon {
            width: 45px;
            height: 45px;
            margin: 0 auto 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 14px;
            color: #64748b;
            background: #f1f5f9;
            font-size: 20px;
        }

        .empty-orders h3 {
            margin: 0;
            color: #1e293b;
            font-size: 14px;
        }

        .empty-orders p {
            margin: 5px 0 0;
            color: #94a3b8;
            font-size: 11px;
        }


        /* RESPONSIVE */

        @media (max-width: 1200px) {

            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }

            .quick-grid {
                grid-template-columns: repeat(2, 1fr);
            }

        }


        @media (max-width: 900px) {

            .dashboard-header {
                align-items: flex-start;
                flex-direction: column;
            }

            .dashboard-main-grid {
                grid-template-columns: 1fr;
            }

        }


        @media (max-width: 640px) {

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .quick-grid {
                grid-template-columns: 1fr;
            }

            .dashboard-header h1 {
                font-size: 30px;
            }

            .dashboard-actions {
                width: 100%;
            }

            .dashboard-actions a {
                flex: 1;
            }

        }

    </style>

</x-filament-panels::page>
