<x-filament-panels::page>
<div class="grid grid-cols-1 gap-5 md:grid-cols-2">
<div class="fi-section rounded-2xl border border-gray-200 bg-white p-6 dark:border-white/10 dark:bg-white/[.03]"><div class="text-xs font-semibold uppercase tracking-widest text-primary-600">Admin account</div><div class="mt-2 text-xl font-bold">{{ auth()->user()->name }}</div><p class="mt-1 text-sm text-gray-500">{{ auth()->user()->email }}</p><a class="fi-btn fi-btn-color-primary mt-5 inline-flex" href="{{ route('profile.edit') }}">Edit profile</a></div>
<div class="fi-section rounded-2xl border border-gray-200 bg-white p-6 dark:border-white/10 dark:bg-white/[.03]"><div class="text-xs font-semibold uppercase tracking-widest text-primary-600">Appearance</div><div class="mt-2 text-xl font-bold">Premium themes</div><p class="mt-1 text-sm text-gray-500">Use the floating control in the bottom-right to switch between Navy / White and Black / Gold / White.</p></div>
</div>
</x-filament-panels::page>