<x-filament-panels::page>
<div class="grid grid-cols-1 gap-4 md:grid-cols-4">
 @foreach([['Total units',$totalUnits,'All inventory'],['Low stock',$lowStock,'1–5 units'],['Out of stock',$outOfStock,'Needs restock'],['Products',$products->count(),'Showing latest']] as $s)
 <div class="fi-section rounded-2xl border border-gray-200 bg-white p-5 shadow-sm dark:border-white/10 dark:bg-white/[.03]"><div class="text-xs font-semibold uppercase tracking-widest text-gray-500">{{ $s[0] }}</div><div class="mt-2 text-3xl font-extrabold tracking-tight text-gray-950 dark:text-white">{{ $s[1] }}</div><div class="mt-1 text-xs text-primary-600">{{ $s[2] }}</div></div>
 @endforeach
</div>
<div class="fi-section mt-5 overflow-hidden rounded-2xl border border-gray-200 bg-white dark:border-white/10 dark:bg-white/[.03]">
<div class="p-5"><h2 class="text-lg font-bold">Stock monitor</h2><p class="text-sm text-gray-500">Use Edit on a product to adjust stock, pricing and availability.</p></div>
<div class="overflow-x-auto"><table class="w-full text-left text-sm"><thead class="bg-gray-50 text-xs uppercase tracking-wider text-gray-500 dark:bg-white/[.03]"><tr><th class="px-5 py-3">Product</th><th class="px-5 py-3">Category</th><th class="px-5 py-3">Stock</th><th class="px-5 py-3">Status</th><th class="px-5 py-3">Action</th></tr></thead><tbody class="divide-y divide-gray-100 dark:divide-white/10">
@foreach($products as $product)<tr><td class="px-5 py-4 font-semibold">{{ $product->name }}</td><td class="px-5 py-4 text-gray-500">{{ $product->category?->name }}</td><td class="px-5 py-4 font-bold">{{ $product->stock }}</td><td class="px-5 py-4">@if($product->stock===0)<span class="text-danger-600">Out of stock</span>@elseif($product->stock<=5)<span class="text-warning-600">Low stock</span>@else<span class="text-success-600">Healthy</span>@endif</td><td class="px-5 py-4"><a class="fi-btn fi-btn-size-sm fi-btn-color-gray inline-flex" href="{{ \App\Filament\Resources\Products\ProductResource::getUrl('edit',['record'=>$product]) }}">Edit product</a></td></tr>@endforeach
</tbody></table></div></div>
</x-filament-panels::page>