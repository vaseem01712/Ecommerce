<x-filament-panels::page>

    @php
        $order = $this->record;

        $status = strtolower((string) ($order->status ?? 'pending'));
        $paymentStatus = strtolower((string) ($order->payment_status ?? 'unpaid'));

        $statusClasses = match ($status) {
            'completed', 'delivered', 'paid' =>
                'bg-emerald-50 text-emerald-700 ring-emerald-200',

            'cancelled', 'canceled', 'failed' =>
                'bg-rose-50 text-rose-700 ring-rose-200',

            'processing', 'shipped' =>
                'bg-blue-50 text-blue-700 ring-blue-200',

            default =>
                'bg-amber-50 text-amber-700 ring-amber-200',
        };

        $paymentClasses = match ($paymentStatus) {
            'paid', 'completed' =>
                'bg-emerald-50 text-emerald-700 ring-emerald-200',

            'failed', 'refunded' =>
                'bg-rose-50 text-rose-700 ring-rose-200',

            default =>
                'bg-amber-50 text-amber-700 ring-amber-200',
        };

        $customerName = $order->name ?? 'Guest Customer';
        $customerEmail = $order->email ?? 'No email available';
        $customerPhone = $order->phone ?? 'No phone available';

        $subtotal = (float) ($order->subtotal ?? 0);
        $shipping = (float) ($order->shipping ?? 0);
        $total = (float) ($order->total ?? ($subtotal + $shipping));

        $initials = collect(explode(' ', trim($customerName)))
            ->filter()
            ->map(fn ($word) => strtoupper(substr($word, 0, 1)))
            ->take(2)
            ->implode('');

        $orderDate = $order->created_at
            ? \Carbon\Carbon::parse($order->created_at)->format('d M Y, h:i A')
            : '—';
    @endphp


    <div class="order-view-page">

        {{-- ========================================================= --}}
        {{-- TOP HEADER --}}
        {{-- ========================================================= --}}

        <div class="order-header">

            <div class="order-header-left">

                <div class="order-breadcrumb">
                    <a href="{{ \App\Filament\Resources\Orders\OrderResource::getUrl('index') }}">
                        Orders
                    </a>

                    <span>/</span>

                    <span>Order #{{ $order->id }}</span>
                </div>

                <div class="order-title-row">

                    <div>
                        <h1>
                            Order #{{ $order->id }}
                        </h1>

                        <p>
                            Placed on {{ $orderDate }}
                        </p>
                    </div>

                    <span class="status-badge {{ $statusClasses }}">
                        <span class="status-dot"></span>
                        {{ ucfirst($status) }}
                    </span>

                </div>

            </div>


            <div class="order-header-actions">

                <a
                    href="{{ \App\Filament\Resources\Orders\OrderResource::getUrl('edit', ['record' => $order]) }}"
                    class="edit-order-button"
                >
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="2"
                            d="M11 5h2m-1-1v2m8.586 6.586a2 2 0 010 2.828l-7.172 7.172a2 2 0 01-1.414.586H6a1 1 0 01-1-1v-5a2 2 0 01.586-1.414l7.172-7.172a2 2 0 012.828 0z"
                        />
                    </svg>

                    Edit Order
                </a>

            </div>

        </div>


        {{-- ========================================================= --}}
        {{-- SUMMARY CARDS --}}
        {{-- ========================================================= --}}

        <div class="summary-grid">

            {{-- Total --}}
            <div class="summary-card">

                <div class="summary-icon total-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="1.8"
                            d="M12 3v18m4-14H9.5a2.5 2.5 0 000 5h5a2.5 2.5 0 010 5H8"
                        />
                    </svg>
                </div>

                <div>
                    <span>Order Total</span>
                    <strong>
                        ${{ number_format($total, 2) }}
                    </strong>
                </div>

            </div>


            {{-- Subtotal --}}
            <div class="summary-card">

                <div class="summary-icon purple-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="1.8"
                            d="M4 6h16M4 10h16M7 14h10M7 18h6"
                        />
                    </svg>
                </div>

                <div>
                    <span>Subtotal</span>
                    <strong>
                        ${{ number_format($subtotal, 2) }}
                    </strong>
                </div>

            </div>


            {{-- Shipping --}}
            <div class="summary-card">

                <div class="summary-icon blue-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="1.8"
                            d="M3 7h11v10H3zM14 10h4l3 3v4h-7zM7 20a2 2 0 100-4 2 2 0 000 4zm10 0a2 2 0 100-4 2 2 0 000 4z"
                        />
                    </svg>
                </div>

                <div>
                    <span>Shipping</span>
                    <strong>
                        ${{ number_format($shipping, 2) }}
                    </strong>
                </div>

            </div>


            {{-- Payment --}}
            <div class="summary-card">

                <div class="summary-icon green-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="1.8"
                            d="M3 7h18v10H3zM3 11h18"
                        />
                    </svg>
                </div>

                <div>
                    <span>Payment</span>

                    <strong class="payment-text">
                        {{ ucfirst($paymentStatus) }}
                    </strong>
                </div>

            </div>

        </div>


        {{-- ========================================================= --}}
        {{-- MAIN CONTENT --}}
        {{-- ========================================================= --}}

        <div class="order-main-grid">

            {{-- ===================================================== --}}
            {{-- LEFT COLUMN --}}
            {{-- ===================================================== --}}

            <div class="order-left-column">


                {{-- CUSTOMER --}}
                <div class="premium-card">

                    <div class="card-header">

                        <div>
                            <h2>Customer Information</h2>
                            <p>Details associated with this order.</p>
                        </div>

                        <div class="card-header-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    stroke-width="1.8"
                                    d="M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2M9 11a4 4 0 100-8 4 4 0 000 8zm13 10v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"
                                />
                            </svg>
                        </div>

                    </div>


                    <div class="customer-profile">

                        <div class="customer-avatar">
                            {{ $initials ?: 'GU' }}
                        </div>

                        <div class="customer-profile-info">

                            <h3>
                                {{ $customerName }}
                            </h3>

                            <p>
                                Customer #{{ $order->id }}
                            </p>

                        </div>

                    </div>


                    <div class="info-grid">

                        <div class="info-item">

                            <span class="info-label">
                                Email
                            </span>

                            <a
                                href="mailto:{{ $customerEmail }}"
                                class="info-value info-link"
                            >
                                {{ $customerEmail }}
                            </a>

                        </div>


                        <div class="info-item">

                            <span class="info-label">
                                Phone
                            </span>

                            <span class="info-value">
                                {{ $customerPhone }}
                            </span>

                        </div>

                    </div>

                </div>


                {{-- SHIPPING ADDRESS --}}
                <div class="premium-card">

                    <div class="card-header">

                        <div>
                            <h2>Shipping Address</h2>
                            <p>Delivery information for this order.</p>
                        </div>

                        <div class="card-header-icon blue-card-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    stroke-width="1.8"
                                    d="M12 21s7-5.4 7-12a7 7 0 10-14 0c0 6.6 7 12 7 12z"
                                />
                                <circle cx="12" cy="9" r="2.3" stroke-width="1.8"/>
                            </svg>
                        </div>

                    </div>


                    <div class="address-box">

                        <div class="address-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    stroke-width="1.8"
                                    d="M4 10l8-6 8 6v9a1 1 0 01-1 1H5a1 1 0 01-1-1z"
                                />
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    stroke-width="1.8"
                                    d="M9 20v-6h6v6"
                                />
                            </svg>
                        </div>

                        <div>

                            <strong>
                                Delivery Address
                            </strong>

                            <p>
                                {{ $order->address ?? '—' }}
                            </p>

                        </div>

                    </div>


                    <div class="location-grid">

                        <div>
                            <span>City</span>
                            <strong>{{ $order->city ?? '—' }}</strong>
                        </div>

                        <div>
                            <span>State</span>
                            <strong>{{ $order->state ?? '—' }}</strong>
                        </div>

                        <div>
                            <span>ZIP Code</span>
                            <strong>{{ $order->zip ?? '—' }}</strong>
                        </div>

                    </div>

                </div>


                {{-- ORDER STATUS --}}
                <div class="premium-card">

                    <div class="card-header">

                        <div>
                            <h2>Order Status</h2>
                            <p>Current order and payment status.</p>
                        </div>

                    </div>


                    <div class="status-row">

                        <div class="status-detail">

                            <span class="info-label">
                                Order Status
                            </span>

                            <span class="large-status {{ $statusClasses }}">
                                <span class="status-dot"></span>
                                {{ ucfirst($status) }}
                            </span>

                        </div>


                        <div class="status-detail">

                            <span class="info-label">
                                Payment Status
                            </span>

                            <span class="large-status {{ $paymentClasses }}">
                                <span class="status-dot"></span>
                                {{ ucfirst($paymentStatus) }}
                            </span>

                        </div>

                    </div>

                </div>

            </div>


            {{-- ===================================================== --}}
            {{-- RIGHT COLUMN --}}
            {{-- ===================================================== --}}

            <div class="order-right-column">


                {{-- ORDER SUMMARY --}}
                <div class="premium-card summary-side-card">

                    <div class="card-header">

                        <div>
                            <h2>Order Summary</h2>
                            <p>Financial breakdown.</p>
                        </div>

                        <div class="card-header-icon purple-card-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    stroke-width="1.8"
                                    d="M6 3h12v18H6zM9 7h6M9 11h6M9 15h4"
                                />
                            </svg>
                        </div>

                    </div>


                    <div class="financial-list">

                        <div class="financial-row">
                            <span>Subtotal</span>
                            <strong>
                                ${{ number_format($subtotal, 2) }}
                            </strong>
                        </div>

                        <div class="financial-row">
                            <span>Shipping</span>
                            <strong>
                                ${{ number_format($shipping, 2) }}
                            </strong>
                        </div>

                        <div class="financial-divider"></div>

                        <div class="financial-total">
                            <span>Total</span>

                            <strong>
                                ${{ number_format($total, 2) }}
                            </strong>
                        </div>

                    </div>

                </div>


                {{-- PAYMENT --}}
                <div class="premium-card">

                    <div class="card-header">

                        <div>
                            <h2>Payment</h2>
                            <p>Payment information.</p>
                        </div>

                        <div class="card-header-icon green-card-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    stroke-width="1.8"
                                    d="M3 7h18v10H3zM3 11h18"
                                />
                            </svg>
                        </div>

                    </div>


                    <div class="payment-box">

                        <div>

                            <span>
                                Payment Status
                            </span>

                            <strong>
                                {{ ucfirst($paymentStatus) }}
                            </strong>

                        </div>

                        <span class="payment-badge {{ $paymentClasses }}">
                            {{ ucfirst($paymentStatus) }}
                        </span>

                    </div>

                </div>


                {{-- ORDER META --}}
                <div class="premium-card">

                    <div class="card-header">

                        <div>
                            <h2>Order Details</h2>
                            <p>Reference information.</p>
                        </div>

                    </div>


                    <div class="meta-list">

                        <div class="meta-row">
                            <span>Order ID</span>
                            <strong>#{{ $order->id }}</strong>
                        </div>

                        <div class="meta-row">
                            <span>Created</span>
                            <strong>{{ $orderDate }}</strong>
                        </div>

                        <div class="meta-row">
                            <span>Customer</span>
                            <strong>{{ $customerName }}</strong>
                        </div>

                    </div>

                </div>


                {{-- QUICK ACTION --}}
                <a
                    href="{{ \App\Filament\Resources\Orders\OrderResource::getUrl('edit', ['record' => $order]) }}"
                    class="quick-action"
                >

                    <div class="quick-action-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                stroke-width="2"
                                d="M11 5h2m-1-1v2m8.586 6.586a2 2 0 010 2.828l-7.172 7.172a2 2 0 01-1.414.586H6a1 1 0 01-1-1v-5a2 2 0 01.586-1.414l7.172-7.172a2 2 0 012.828 0z"
                            />
                        </svg>
                    </div>

                    <div>
                        <strong>
                            Manage this order
                        </strong>

                        <span>
                            Update order information
                        </span>
                    </div>

                    <svg
                        class="arrow-icon"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                    >
                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="2"
                            d="M9 5l7 7-7 7"
                        />
                    </svg>

                </a>

            </div>

        </div>

    </div>


    <style>
        .order-view-page {
            max-width: 1500px;
            margin: 0 auto;
            padding-bottom: 50px;
        }

        .order-header {
            display: flex;
            align-items: flex-end;
            justify-content: space-between;
            gap: 24px;
            margin-bottom: 28px;
        }

        .order-breadcrumb {
            display: flex;
            align-items: center;
            gap: 9px;
            margin-bottom: 12px;
            font-size: 13px;
            color: #94a3b8;
        }

        .order-breadcrumb a {
            color: #64748b;
            text-decoration: none;
            transition: color .2s ease;
        }

        .order-breadcrumb a:hover {
            color: #2563eb;
        }

        .order-title-row {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .order-title-row h1 {
            margin: 0;
            color: #0f172a;
            font-size: 34px;
            line-height: 1.1;
            font-weight: 750;
            letter-spacing: -0.035em;
        }

        .order-title-row p {
            margin: 8px 0 0;
            color: #64748b;
            font-size: 14px;
        }

        .status-badge,
        .large-status,
        .payment-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            border-radius: 999px;
            box-shadow: inset 0 0 0 1px;
        }

        .status-badge {
            padding: 7px 12px;
            font-size: 12px;
            font-weight: 700;
        }

        .status-dot {
            width: 7px;
            height: 7px;
            border-radius: 50%;
            background: currentColor;
        }

        .edit-order-button {
            display: inline-flex;
            align-items: center;
            gap: 9px;
            padding: 11px 17px;
            border-radius: 12px;
            background: #0f172a;
            color: white;
            text-decoration: none;
            font-size: 13px;
            font-weight: 700;
            box-shadow: 0 8px 22px rgba(15, 23, 42, .16);
            transition: transform .2s ease, box-shadow .2s ease, background .2s ease;
        }

        .edit-order-button:hover {
            color: white;
            background: #1e293b;
            transform: translateY(-2px);
            box-shadow: 0 13px 28px rgba(15, 23, 42, .20);
        }

        .edit-order-button svg {
            width: 17px;
            height: 17px;
        }

        .summary-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 16px;
            margin-bottom: 20px;
        }

        .summary-card {
            display: flex;
            align-items: center;
            gap: 14px;
            min-height: 105px;
            padding: 19px;
            border: 1px solid #e2e8f0;
            border-radius: 18px;
            background: rgba(255,255,255,.88);
            box-shadow: 0 10px 30px rgba(15,23,42,.055);
            transition: transform .2s ease, box-shadow .2s ease;
        }

        .summary-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 15px 35px rgba(15,23,42,.09);
        }

        .summary-card > div:last-child {
            min-width: 0;
        }

        .summary-card span {
            display: block;
            color: #64748b;
            font-size: 12px;
            font-weight: 600;
            margin-bottom: 5px;
        }

        .summary-card strong {
            display: block;
            color: #0f172a;
            font-size: 21px;
            font-weight: 750;
            letter-spacing: -.02em;
        }

        .summary-icon {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 46px;
            height: 46px;
            flex: 0 0 46px;
            border-radius: 14px;
        }

        .summary-icon svg {
            width: 21px;
            height: 21px;
        }

        .total-icon {
            background: #eff6ff;
            color: #2563eb;
        }

        .purple-icon {
            background: #f5f3ff;
            color: #7c3aed;
        }

        .blue-icon {
            background: #ecfeff;
            color: #0891b2;
        }

        .green-icon {
            background: #ecfdf5;
            color: #059669;
        }

        .payment-text {
            font-size: 17px !important;
        }

        .order-main-grid {
            display: grid;
            grid-template-columns: minmax(0, 1.65fr) minmax(320px, .85fr);
            gap: 20px;
            align-items: start;
        }

        .order-left-column,
        .order-right-column {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .premium-card {
            overflow: hidden;
            border: 1px solid #e2e8f0;
            border-radius: 20px;
            background: rgba(255,255,255,.94);
            box-shadow: 0 10px 35px rgba(15,23,42,.055);
        }

        .card-header {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 20px;
            padding: 21px 22px;
            border-bottom: 1px solid #eef2f7;
        }

        .card-header h2 {
            margin: 0;
            color: #0f172a;
            font-size: 16px;
            font-weight: 750;
            letter-spacing: -.015em;
        }

        .card-header p {
            margin: 5px 0 0;
            color: #94a3b8;
            font-size: 12px;
        }

        .card-header-icon {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 38px;
            height: 38px;
            flex: 0 0 38px;
            border-radius: 11px;
            background: #eff6ff;
            color: #2563eb;
        }

        .card-header-icon svg {
            width: 18px;
            height: 18px;
        }

        .blue-card-icon {
            background: #ecfeff;
            color: #0891b2;
        }

        .purple-card-icon {
            background: #f5f3ff;
            color: #7c3aed;
        }

        .green-card-icon {
            background: #ecfdf5;
            color: #059669;
        }

        .customer-profile {
            display: flex;
            align-items: center;
            gap: 14px;
            padding: 22px;
            border-bottom: 1px solid #eef2f7;
        }

        .customer-avatar {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 52px;
            height: 52px;
            flex: 0 0 52px;
            border-radius: 15px;
            background: linear-gradient(135deg, #2563eb, #4f46e5);
            color: white;
            font-size: 17px;
            font-weight: 800;
            box-shadow: 0 8px 20px rgba(37,99,235,.22);
        }

        .customer-profile-info h3 {
            margin: 0;
            color: #0f172a;
            font-size: 16px;
            font-weight: 750;
        }

        .customer-profile-info p {
            margin: 4px 0 0;
            color: #94a3b8;
            font-size: 12px;
        }

        .info-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 1px;
            background: #eef2f7;
        }

        .info-item {
            padding: 18px 22px;
            background: white;
        }

        .info-label {
            display: block;
            margin-bottom: 7px;
            color: #94a3b8;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .08em;
        }

        .info-value {
            display: block;
            color: #334155;
            font-size: 13px;
            font-weight: 600;
            word-break: break-word;
        }

        .info-link {
            color: #2563eb;
            text-decoration: none;
        }

        .info-link:hover {
            text-decoration: underline;
        }

        .address-box {
            display: flex;
            gap: 14px;
            margin: 20px 22px;
            padding: 17px;
            border: 1px solid #e2e8f0;
            border-radius: 14px;
            background: #f8fafc;
        }

        .address-icon {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 38px;
            height: 38px;
            flex: 0 0 38px;
            border-radius: 11px;
            background: white;
            color: #2563eb;
            box-shadow: 0 3px 10px rgba(15,23,42,.06);
        }

        .address-icon svg {
            width: 18px;
            height: 18px;
        }

        .address-box strong {
            display: block;
            margin-bottom: 5px;
            color: #334155;
            font-size: 13px;
        }

        .address-box p {
            margin: 0;
            color: #64748b;
            font-size: 13px;
            line-height: 1.6;
        }

        .location-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 1px;
            background: #eef2f7;
        }

        .location-grid > div {
            padding: 17px 22px;
            background: white;
        }

        .location-grid span {
            display: block;
            margin-bottom: 6px;
            color: #94a3b8;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .08em;
        }

        .location-grid strong {
            color: #334155;
            font-size: 13px;
        }

        .status-row {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 1px;
            background: #eef2f7;
        }

        .status-detail {
            padding: 20px 22px;
            background: white;
        }

        .large-status {
            width: fit-content;
            padding: 9px 13px;
            font-size: 12px;
            font-weight: 700;
        }

        .financial-list {
            padding: 8px 22px 22px;
        }

        .financial-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            padding: 14px 0;
        }

        .financial-row span {
            color: #64748b;
            font-size: 13px;
        }

        .financial-row strong {
            color: #334155;
            font-size: 13px;
        }

        .financial-divider {
            height: 1px;
            background: #e2e8f0;
            margin: 4px 0;
        }

        .financial-total {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            padding-top: 17px;
        }

        .financial-total span {
            color: #0f172a;
            font-size: 14px;
            font-weight: 750;
        }

        .financial-total strong {
            color: #2563eb;
            font-size: 23px;
            font-weight: 800;
            letter-spacing: -.025em;
        }

        .payment-box {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
            padding: 20px 22px;
        }

        .payment-box span:first-child {
            display: block;
            color: #94a3b8;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .08em;
            margin-bottom: 5px;
        }

        .payment-box strong {
            color: #0f172a;
            font-size: 14px;
        }

        .payment-badge {
            padding: 7px 11px;
            font-size: 11px;
            font-weight: 750;
        }

        .meta-list {
            padding: 8px 22px 18px;
        }

        .meta-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            padding: 13px 0;
            border-bottom: 1px solid #f1f5f9;
        }

        .meta-row:last-child {
            border-bottom: 0;
        }

        .meta-row span {
            color: #94a3b8;
            font-size: 12px;
        }

        .meta-row strong {
            max-width: 65%;
            color: #334155;
            font-size: 12px;
            text-align: right;
            word-break: break-word;
        }

        .quick-action {
            display: flex;
            align-items: center;
            gap: 13px;
            padding: 17px;
            border: 1px solid #dbeafe;
            border-radius: 18px;
            background: linear-gradient(135deg, #eff6ff, #f5f3ff);
            color: #0f172a;
            text-decoration: none;
            transition: transform .2s ease, box-shadow .2s ease;
        }

        .quick-action:hover {
            color: #0f172a;
            transform: translateY(-2px);
            box-shadow: 0 14px 30px rgba(37,99,235,.10);
        }

        .quick-action-icon {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            flex: 0 0 40px;
            border-radius: 12px;
            background: white;
            color: #2563eb;
            box-shadow: 0 5px 15px rgba(15,23,42,.07);
        }

        .quick-action-icon svg {
            width: 18px;
            height: 18px;
        }

        .quick-action strong {
            display: block;
            margin-bottom: 3px;
            font-size: 13px;
            font-weight: 750;
        }

        .quick-action span {
            display: block;
            color: #64748b;
            font-size: 11px;
        }

        .arrow-icon {
            width: 18px;
            height: 18px;
            margin-left: auto;
            color: #94a3b8;
        }


        /* --------------------------------------------------------- */
        /* RESPONSIVE */
        /* --------------------------------------------------------- */

        @media (max-width: 1100px) {

            .summary-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            .order-main-grid {
                grid-template-columns: 1fr;
            }

        }


        @media (max-width: 700px) {

            .order-header {
                align-items: stretch;
                flex-direction: column;
            }

            .order-title-row {
                align-items: flex-start;
                flex-direction: column;
            }

            .order-title-row h1 {
                font-size: 28px;
            }

            .order-header-actions {
                width: 100%;
            }

            .edit-order-button {
                justify-content: center;
                width: 100%;
            }

            .summary-grid {
                grid-template-columns: 1fr;
            }

            .info-grid,
            .status-row,
            .location-grid {
                grid-template-columns: 1fr;
            }

            .card-header,
            .customer-profile,
            .address-box,
            .payment-box {
                padding-left: 17px;
                padding-right: 17px;
            }

            .info-item,
            .location-grid > div,
            .status-detail {
                padding-left: 17px;
                padding-right: 17px;
            }

            .financial-list,
            .meta-list {
                padding-left: 17px;
                padding-right: 17px;
            }

        }
    </style>

</x-filament-panels::page>
