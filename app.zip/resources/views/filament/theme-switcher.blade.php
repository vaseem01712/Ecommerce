<link rel="stylesheet" href="{{ asset('filament-admin.css') }}">
<div class="mystore-admin-theme-fab" aria-label="Theme switcher">
<button data-admin-theme="blue" onclick="window.MyStoreAdminTheme('blue')" title="Navy blue / white">◐</button>
<button data-admin-theme="luxury" onclick="window.MyStoreAdminTheme('luxury')" title="Black / gold / white">◆</button>
</div>
<script>
(function(){
 const root=document.documentElement;
 const apply=t=>{root.dataset.storeTheme=t==='luxury'?'luxury':'blue';localStorage.setItem('mystore-theme',root.dataset.storeTheme);document.querySelectorAll('[data-admin-theme]').forEach(b=>b.classList.toggle('active',b.dataset.adminTheme===root.dataset.storeTheme));};
 window.MyStoreAdminTheme=apply; apply(localStorage.getItem('mystore-theme')||'blue');
})();
</script>