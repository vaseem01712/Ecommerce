<?php

namespace App\Filament\Resources\Customers\Schemas;

use Filament\Infolists\Components\TextEntry;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;

class CustomerInfolist
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([

                /*
                |--------------------------------------------------------------------------
                | Customer Profile
                |--------------------------------------------------------------------------
                */

                Section::make('Customer Profile')
                    ->description('Basic customer information and account details.')
                    ->icon('heroicon-o-user-circle')
                    ->schema([

                        TextEntry::make('name')
                            ->label('Full Name')
                            ->icon('heroicon-o-user')
                            ->weight('bold')
                            ->size('lg'),

                        TextEntry::make('email')
                            ->label('Email Address')
                            ->icon('heroicon-o-envelope')
                            ->copyable()
                            ->copyMessage('Email copied'),

                        TextEntry::make('created_at')
                            ->label('Customer Since')
                            ->icon('heroicon-o-calendar-days')
                            ->dateTime('d M Y, h:i A'),

                        TextEntry::make('orders_count')
                            ->label('Total Orders')
                            ->icon('heroicon-o-shopping-bag')
                            ->state(function ($record) {
                                try {
                                    return $record->orders()->count();
                                } catch (\Throwable $e) {
                                    return 0;
                                }
                            })
                            ->badge()
                            ->color('primary'),

                    ])
                    ->columns(2),

                /*
                |--------------------------------------------------------------------------
                | Account Overview
                |--------------------------------------------------------------------------
                */

                Section::make('Account Overview')
                    ->description('Customer account activity and status.')
                    ->icon('heroicon-o-chart-bar')
                    ->schema([

                        TextEntry::make('account_status')
                            ->label('Account Status')
                            ->state('Active')
                            ->badge()
                            ->color('success')
                            ->icon('heroicon-o-check-circle'),

                        TextEntry::make('customer_id')
                            ->label('Customer ID')
                            ->state(fn ($record) => '#' . $record->id)
                            ->copyable()
                            ->icon('heroicon-o-identification'),

                    ])
                    ->columns(2),

                /*
                |--------------------------------------------------------------------------
                | Orders
                |--------------------------------------------------------------------------
                */

                Section::make('Order History')
                    ->description('Orders placed by this customer.')
                    ->icon('heroicon-o-shopping-cart')
                    ->schema([

                        TextEntry::make('orders_summary')
                            ->label('Orders')
                            ->state(function ($record) {
                                try {
                                    $count = $record->orders()->count();

                                    return $count === 0
                                        ? 'No orders placed yet'
                                        : $count . ' order' . ($count === 1 ? '' : 's') . ' placed';
                                } catch (\Throwable $e) {
                                    return 'No orders placed yet';
                                }
                            })
                            ->placeholder('No orders placed yet')
                            ->size('lg')
                            ->weight('bold'),

                    ]),

            ]);
    }
}
