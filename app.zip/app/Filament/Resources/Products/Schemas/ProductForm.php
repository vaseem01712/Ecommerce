<?php

namespace App\Filament\Resources\Products\Schemas;

use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Schemas\Schema;

class ProductForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Select::make('category_id')
                    ->label('Category')
                    ->relationship('category', 'name')
                    ->required(),
                TextInput::make('name')
                    ->required()
                    ->maxLength(255),
                TextInput::make('slug')
                    ->required()
                    ->maxLength(255),
                Textarea::make('description')
                    ->nullable(),
                TextInput::make('price')
                    ->numeric()
                    ->required()
                    ->prefix('$'),
                TextInput::make('sale_price')
                    ->numeric()
                    ->nullable()
                    ->prefix('$'),
                TextInput::make('stock')
                    ->numeric()
                    ->required()
                    ->default(0),
                FileUpload::make('image')
                    ->image()
                    ->nullable(),
                Toggle::make('is_active')
                    ->default(true),
                Toggle::make('is_featured')
                    ->default(false),
            ]);
    }
}

