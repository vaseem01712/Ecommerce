<?php
namespace App\Filament\Resources\Orders\Schemas;
use Filament\Infolists\Components\TextEntry;
use Filament\Schemas\Schema;
class OrderInfolist {
 public static function configure(Schema $schema): Schema { return $schema->components([
  TextEntry::make('id')->label('Order #'),TextEntry::make('name'),TextEntry::make('email'),TextEntry::make('phone'),
  TextEntry::make('address')->columnSpanFull(),TextEntry::make('city'),TextEntry::make('state'),TextEntry::make('zip'),
  TextEntry::make('subtotal')->money('USD'),TextEntry::make('shipping')->money('USD'),TextEntry::make('total')->money('USD'),
  TextEntry::make('status')->badge(),TextEntry::make('payment_status')->badge(),
 ]); }
}

