<?php
namespace App\Filament\Pages;

use BackedEnum;
use App\Models\Product;
use Filament\Pages\Page;
use Filament\Support\Icons\Heroicon;
use Illuminate\Contracts\Support\Htmlable;

class Inventory extends Page
{
    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedArchiveBox;
    protected static ?string $navigationLabel = 'Inventory';
    protected static ?string $title = 'Inventory';
    protected static ?int $navigationSort = 30;
    protected static string|\UnitEnum|null $navigationGroup = 'Operations';
    protected string $view = 'filament.pages.inventory';

    public function getViewData(): array
    {
        return [
            'totalUnits' => Product::sum('stock'),
            'lowStock' => Product::whereBetween('stock',[1,5])->count(),
            'outOfStock' => Product::where('stock',0)->count(),
            'products' => Product::with('category')->orderBy('stock')->take(30)->get(),
        ];
    }
}

