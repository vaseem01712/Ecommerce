<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;

class ProductController extends Controller
{
    public function index()
    {
        $products = Product::with('category')->where('is_active', true)->paginate(12);
        return view('products.index', compact('products'));
    }

    public function show($slug)
    {
        $product = Product::where('slug', $slug)
                         ->where('is_active', true)
                         ->firstOrFail();
        return view('products.show', compact('product'));
    }

    public function category($slug)
    {
        $category = Category::where('slug', $slug)->firstOrFail();
        $products = Product::with('category')->where('category_id', $category->id)
                          ->where('is_active', true)
                          ->paginate(12);
        return view('products.category', compact('category', 'products'));
    }
}