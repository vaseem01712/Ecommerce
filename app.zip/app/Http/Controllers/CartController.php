<?php

namespace App\Http\Controllers;

use App\Models\CartItem;
use App\Models\Product;
use Illuminate\Http\Request;

class CartController extends Controller
{
    public function index()
    {
        $cartItems = CartItem::where('user_id', auth()->id())
                            ->with('product')
                            ->get();
        $total = $cartItems->sum(fn($item) => $item->product->price * $item->quantity);
        return view('cart.index', compact('cartItems', 'total'));
    }

    public function add(Request $request, Product $product)
    {
        $cartItem = CartItem::where('user_id', auth()->id())
                           ->where('product_id', $product->id)
                           ->first();
        if ($cartItem) {
            $cartItem->increment('quantity');
        } else {
            CartItem::create([
                'user_id' => auth()->id(),
                'product_id' => $product->id,
                'quantity' => 1,
            ]);
        }
        return back()->with('success', 'Product added to cart!');
    }

    public function update(Request $request, $id)
    {
        CartItem::where('id', $id)
               ->where('user_id', auth()->id())
               ->update(['quantity' => $request->quantity]);
        return back()->with('success', 'Cart updated!');
    }

    public function remove($id)
    {
        CartItem::where('id', $id)
               ->where('user_id', auth()->id())
               ->delete();
        return back()->with('success', 'Item removed!');
    }
}