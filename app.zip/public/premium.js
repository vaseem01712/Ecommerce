
(function(){
 const root=document.documentElement;
 const saved=localStorage.getItem('mystore-theme')||'blue';
 root.dataset.theme=saved==='luxury'?'luxury':'blue';
 window.setStoreTheme=function(theme){
   root.dataset.theme=theme==='luxury'?'luxury':'blue';
   localStorage.setItem('mystore-theme',root.dataset.theme);
   document.querySelectorAll('[data-theme-btn]').forEach(b=>b.classList.toggle('active',b.dataset.themeBtn===root.dataset.theme));
 };
 document.addEventListener('DOMContentLoaded',()=>{
   setStoreTheme(root.dataset.theme);
   document.querySelectorAll('[data-like]').forEach(btn=>{
     const id=btn.dataset.like, key='mystore-like-'+id;
     const sync=()=>{const liked=localStorage.getItem(key)==='1';btn.classList.toggle('liked',liked);btn.textContent=liked?'♥':'♡';};
     btn.addEventListener('click',()=>{localStorage.setItem(key,localStorage.getItem(key)==='1'?'0':'1');sync();}); sync();
   });
   document.querySelectorAll('[data-slider]').forEach(slider=>{
     const slides=[...slider.querySelectorAll('.hero-slide')]; if(!slides.length)return;
     let i=0;
     const dots=[...slider.querySelectorAll('.slider-dot')];
     const show=n=>{i=(n+slides.length)%slides.length;slides.forEach((s,j)=>s.classList.toggle('active',j===i));dots.forEach((d,j)=>d.classList.toggle('active',j===i));};
     dots.forEach((d,j)=>d.onclick=()=>show(j));
     slider.querySelector('[data-prev]')?.addEventListener('click',()=>show(i-1));
     slider.querySelector('[data-next]')?.addEventListener('click',()=>show(i+1));
     setInterval(()=>show(i+1),6500);
   });
   document.querySelectorAll('[data-scroll-target]').forEach(btn=>btn.addEventListener('click',()=>{
      document.querySelector(btn.dataset.scrollTarget)?.scrollBy({left:btn.dataset.direction==='left'?-520:520,behavior:'smooth'});
   }));
   const mobile=document.querySelector('[data-mobile-menu]');
   document.querySelector('[data-mobile-toggle]')?.addEventListener('click',()=>mobile?.classList.toggle('open'));
 });
})();
